﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestock
{
    public partial class FormAccueil : Form
    {
        Form1 connectForm;
        public FormAccueil(Form1 accueilForm)
        {
            connectForm = accueilForm;
            InitializeComponent();
        }

        private void buttonDeconnect_Click(object sender, EventArgs e)
        {
            
        }
    }
}
